// lib/features/settings/change_password_screen.dart
import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:firebase_auth/firebase_auth.dart';
import '../../core/theme/app_theme.dart';

enum _CPStep { otp, newPassword }

class ChangePasswordScreen extends StatefulWidget {
  const ChangePasswordScreen({super.key});
  @override State<ChangePasswordScreen> createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  _CPStep _step = _CPStep.otp;

  // ── EmailJS credentials (same as OTP screen) ──────────────────────────────
  static const _serviceId  = 'service_ezvt2r2';
  static const _templateId = 'template_so1q2yf';
  static const _publicKey  = 'C48yDMHg-ri1SjfYx';

  String get _userEmail => FirebaseAuth.instance.currentUser?.email ?? '';

  // ── OTP state ─────────────────────────────────────────────────────────────
  String _generatedOtp = '';
  bool _sending = true;
  final List<TextEditingController> _otpCtrls = List.generate(6, (_) => TextEditingController());
  final List<FocusNode>             _otpNodes = List.generate(6, (_) => FocusNode());
  Timer? _timer;
  int  _seconds   = 60;
  bool _canResend = false;
  bool _otpLoading = false;
  String? _otpError;

  // ── New password state ────────────────────────────────────────────────────
  final _newPassCtrl     = TextEditingController();
  final _confirmPassCtrl = TextEditingController();
  bool _obscureNew     = true;
  bool _obscureConfirm = true;
  bool _resetLoading   = false;
  String? _newPassError;
  String? _confirmPassError;

  @override
  void initState() {
    super.initState();
    _sendOtp();
  }

  @override
  void dispose() {
    _timer?.cancel();
    for (final c in _otpCtrls) {
      c.dispose();
    }
    for (final n in _otpNodes) {
      n.dispose();
    }
    _newPassCtrl.dispose();
    _confirmPassCtrl.dispose();
    super.dispose();
  }

  // ── Send real OTP via EmailJS to the user's registered email ──────────────
  Future<void> _sendOtp() async {
    setState(() { _sending = true; _otpError = null; });
    _generatedOtp = List.generate(6, (_) => Random().nextInt(10)).join();

    try {
      final res = await http.post(
        Uri.parse('https://api.emailjs.com/api/v1.0/email/send'),
        headers: { 'Content-Type': 'application/json', 'origin': 'http://localhost' },
        body: jsonEncode({
          'service_id':  _serviceId,
          'template_id': _templateId,
          'user_id':     _publicKey,
          'template_params': {
            'to_email': _userEmail,
            'otp_code': _generatedOtp,
          },
        }),
      );

      if (!mounted) return;
      if (res.statusCode != 200) {
        setState(() => _otpError = 'Failed to send code. Tap "Resend" to try again.');
      }
    } catch (_) {
      if (!mounted) return;
      setState(() => _otpError = 'Network error. Tap "Resend" to try again.');
    }

    if (mounted) {
      setState(() => _sending = false);
      _startTimer();
    }
  }

  void _startTimer() {
    setState(() { _seconds = 60; _canResend = false; });
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_seconds == 0) {
        t.cancel();
        if (mounted) setState(() => _canResend = true);
      } else {
        if (mounted) setState(() => _seconds--);
      }
    });
  }

  String get _otp => _otpCtrls.map((c) => c.text).join();

  void _onOtpChanged(int i, String val) {
    if (val.isNotEmpty && i < 5) _otpNodes[i + 1].requestFocus();
    setState(() => _otpError = null);
  }

  Future<void> _verifyOtp() async {
    if (_otp.length < 6) return;
    setState(() { _otpLoading = true; _otpError = null; });
    await Future.delayed(const Duration(milliseconds: 300));

    if (_otp == _generatedOtp) {
      setState(() { _otpLoading = false; _step = _CPStep.newPassword; });
    } else {
      setState(() {
        _otpLoading = false;
        _otpError = 'Incorrect code. Please try again.';
        for (final c in _otpCtrls) {
          c.clear();
        }
      });
      _otpNodes[0].requestFocus();
    }
  }

  void _resend() {
    for (final c in _otpCtrls) {
      c.clear();
    }
    setState(() => _otpError = null);
    _otpNodes[0].requestFocus();
    _sendOtp();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('New verification code sent to your email'),
      backgroundColor: AppColors.green,
    ));
  }

  bool _hasUppercase(String p) => p.contains(RegExp(r'[A-Z]'));
  bool _hasDigit(String p)     => p.contains(RegExp(r'[0-9]'));

  Future<void> _changePassword() async {
    final pass    = _newPassCtrl.text;
    final confirm = _confirmPassCtrl.text;
    String? pe, ce;

    if (pass.length < 8) {
      pe = 'Password must be at least 8 characters';
    } else if (!_hasUppercase(pass) || !_hasDigit(pass))
                                   pe = 'Must contain uppercase letters and numbers';
    if (confirm.isEmpty)           ce = 'Please confirm your password';
    if (pass.isNotEmpty && confirm.isNotEmpty && pass != confirm) {
      ce = 'Passwords do not match';
    }

    setState(() { _newPassError = pe; _confirmPassError = ce; });
    if (pe != null || ce != null) return;

    setState(() => _resetLoading = true);

    try {
      await FirebaseAuth.instance.currentUser!.updatePassword(pass);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Password changed successfully!'),
        backgroundColor: AppColors.green,
      ));
      Navigator.pop(context);
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      setState(() {
        _resetLoading = false;
        if (e.code == 'requires-recent-login') {
          _newPassError = 'Session expired. Please sign out and sign back in, then try again.';
        } else {
          _newPassError = e.message ?? 'Failed to update password.';
        }
      });
    } catch (_) {
      if (!mounted) return;
      setState(() { _resetLoading = false; _newPassError = 'Network error. Try again.'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, size: 18),
          onPressed: () {
            if (_step == _CPStep.newPassword) {
              setState(() => _step = _CPStep.otp);
            } else {
              Navigator.pop(context);
            }
          },
        ),
        title: const Text('Change Password'),
      ),
      body: SafeArea(
        child: switch (_step) {
          _CPStep.otp         => _OtpStep(),
          _CPStep.newPassword => _NewPasswordStep(),
        },
      ),
    );
  }

  // ── OTP step ──────────────────────────────────────────────────────────────
  Widget _OtpStep() => SingleChildScrollView(
    padding: const EdgeInsets.all(24),
    child: Column(
      children: [
        const SizedBox(height: 16),
        Container(
          width: 72, height: 72,
          decoration: BoxDecoration(shape: BoxShape.circle,
              border: Border.all(color: AppColors.accent, width: 2)),
          child: const Icon(Icons.mail_outline, color: AppColors.accent, size: 32),
        ),
        const SizedBox(height: 16),
        const Text('Verify Your Identity',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700,
                color: AppColors.textPrimary)),
        const SizedBox(height: 8),
        Text(
          'We sent a 6-digit code to\n$_userEmail',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.6),
        ),
        const SizedBox(height: 28),

        if (_sending)
          const Column(children: [
            CircularProgressIndicator(color: AppColors.accent),
            SizedBox(height: 8),
            Text('Sending code to your email...',
                style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
          ])
        else ...[
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(6, (i) => Container(
              width: 44, height: 52,
              margin: const EdgeInsets.symmetric(horizontal: 4),
              child: TextFormField(
                controller: _otpCtrls[i],
                focusNode: _otpNodes[i],
                textAlign: TextAlign.center,
                keyboardType: TextInputType.number,
                maxLength: 1,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary),
                decoration: InputDecoration(
                  counterText: '',
                  filled: true,
                  fillColor: AppColors.bg3,
                  contentPadding: EdgeInsets.zero,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(
                      color: _otpCtrls[i].text.isNotEmpty ? AppColors.accent : AppColors.border,
                      width: 2,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: AppColors.accent, width: 2),
                  ),
                ),
                onChanged: (val) => _onOtpChanged(i, val),
                onTap: () => _otpCtrls[i].selection = TextSelection.fromPosition(
                    TextPosition(offset: _otpCtrls[i].text.length)),
              ),
            )),
          ),

          if (_otpError != null) ...[
            const SizedBox(height: 10),
            Text(_otpError!, style: const TextStyle(color: AppColors.red, fontSize: 12),
                textAlign: TextAlign.center),
          ],

          const SizedBox(height: 20),
          _otpLoading
              ? const CircularProgressIndicator(color: AppColors.accent)
              : ElevatedButton(
                  onPressed: _otp.length == 6 ? _verifyOtp : null,
                  child: const Text('Verify Code'),
                ),
          const SizedBox(height: 16),

          if (!_canResend)
            Text('Resend code in ${_seconds}s',
                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary))
          else
            GestureDetector(
              onTap: _resend,
              child: const Text('Resend verification code',
                  style: TextStyle(fontSize: 12, color: AppColors.accent,
                      fontWeight: FontWeight.w600)),
            ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.accent.withOpacity(0.06),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.accent.withOpacity(0.2)),
            ),
            child: const Row(children: [
              Icon(Icons.info_outline, color: AppColors.accent, size: 14),
              SizedBox(width: 8),
              Expanded(child: Text(
                'Code expires in 10 minutes. Check your spam folder if not received.',
                style: TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.5),
              )),
            ]),
          ),
        ],
      ],
    ),
  );

  // ── New password step ─────────────────────────────────────────────────────
  Widget _NewPasswordStep() => SingleChildScrollView(
    padding: const EdgeInsets.all(24),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 16),
        Center(
          child: Container(
            width: 72, height: 72,
            decoration: BoxDecoration(shape: BoxShape.circle,
                border: Border.all(color: AppColors.green, width: 2)),
            child: const Icon(Icons.lock_outline, color: AppColors.green, size: 32),
          ),
        ),
        const SizedBox(height: 16),
        const Center(
          child: Text('Set New Password',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary)),
        ),
        const SizedBox(height: 28),

        const Text('New Password',
            style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
        const SizedBox(height: 6),
        TextField(
          controller: _newPassCtrl,
          obscureText: _obscureNew,
          style: const TextStyle(color: AppColors.textPrimary),
          onChanged: (_) => setState(() { _newPassError = null; _confirmPassError = null; }),
          decoration: InputDecoration(
            hintText: 'Min. 8 characters',
            errorText: _newPassError,
            errorStyle: const TextStyle(color: AppColors.red, fontSize: 11),
            suffixIcon: IconButton(
              icon: Icon(_obscureNew ? Icons.visibility_off : Icons.visibility,
                  color: AppColors.textTertiary, size: 18),
              onPressed: () => setState(() => _obscureNew = !_obscureNew),
            ),
          ),
        ),

        if (_newPassCtrl.text.isNotEmpty) ...[
          const SizedBox(height: 8),
          _StrengthRow(_newPassCtrl.text),
        ],

        const SizedBox(height: 16),
        const Text('Confirm Password',
            style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
        const SizedBox(height: 6),
        TextField(
          controller: _confirmPassCtrl,
          obscureText: _obscureConfirm,
          style: const TextStyle(color: AppColors.textPrimary),
          onChanged: (_) => setState(() => _confirmPassError = null),
          decoration: InputDecoration(
            hintText: 'Repeat new password',
            errorText: _confirmPassError,
            errorStyle: const TextStyle(color: AppColors.red, fontSize: 11),
            suffixIcon: IconButton(
              icon: Icon(_obscureConfirm ? Icons.visibility_off : Icons.visibility,
                  color: AppColors.textTertiary, size: 18),
              onPressed: () => setState(() => _obscureConfirm = !_obscureConfirm),
            ),
          ),
        ),
        const SizedBox(height: 24),

        _resetLoading
            ? const Center(child: CircularProgressIndicator(color: AppColors.accent))
            : ElevatedButton(
                onPressed: _changePassword,
                child: const Text('Update Password'),
              ),
      ],
    ),
  );

  Widget _StrengthRow(String pass) {
    final long  = pass.length >= 8;
    final upper = _hasUppercase(pass);
    final digit = _hasDigit(pass);
    Color barColor;
    String label;
    if (long && upper && digit) { barColor = AppColors.green;  label = 'Strong'; }
    else if (long)               { barColor = AppColors.orange; label = 'Medium'; }
    else                         { barColor = AppColors.red;    label = 'Weak';   }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          Expanded(child: ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: long && upper && digit ? 1.0 : long ? 0.6 : 0.3,
              minHeight: 4, backgroundColor: AppColors.bg3, color: barColor,
            ),
          )),
          const SizedBox(width: 8),
          Text(label, style: TextStyle(fontSize: 11, color: barColor,
              fontWeight: FontWeight.w600)),
        ]),
        const SizedBox(height: 4),
        Wrap(spacing: 8, children: [
          _Criterion('8+ chars', long),
          _Criterion('Uppercase', upper),
          _Criterion('Number',    digit),
        ]),
      ],
    );
  }

  Widget _Criterion(String label, bool met) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Icon(met ? Icons.check_circle : Icons.radio_button_unchecked,
          size: 12, color: met ? AppColors.green : AppColors.textTertiary),
      const SizedBox(width: 3),
      Text(label, style: TextStyle(fontSize: 10,
          color: met ? AppColors.green : AppColors.textTertiary)),
    ],
  );
}
