// lib/features/auth/forgot_password_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_functions/cloud_functions.dart';
import '../../core/theme/app_theme.dart';

enum _Step { email, otp, password, done }

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});
  @override State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  _Step _step = _Step.email;

  // ── Step 1 ────────────────────────────────────────────────────────────────
  final _emailCtrl = TextEditingController();
  bool  _emailLoading = false;
  String? _emailError;

  // ── Step 2 ────────────────────────────────────────────────────────────────
  final List<TextEditingController> _otpCtrls = List.generate(6, (_) => TextEditingController());
  final List<FocusNode>             _otpNodes = List.generate(6, (_) => FocusNode());
  Timer? _timer;
  int  _seconds   = 60;
  bool _canResend = false;
  bool _otpLoading  = false;
  bool _otpResending = false;
  String? _otpError;
  String  _verifiedOtp = '';

  // ── Step 3 ────────────────────────────────────────────────────────────────
  final _passCtrl    = TextEditingController();
  final _confirmCtrl = TextEditingController();
  bool _obscurePass    = true;
  bool _obscureConfirm = true;
  bool _passLoading  = false;
  String? _passError;
  String? _confirmError;

  @override
  void dispose() {
    _timer?.cancel();
    _emailCtrl.dispose();
    for (final c in _otpCtrls) {
      c.dispose();
    }
    for (final n in _otpNodes) {
      n.dispose();
    }
    _passCtrl.dispose();
    _confirmCtrl.dispose();
    super.dispose();
  }

  // ── Send OTP via Cloud Function ───────────────────────────────────────────
  Future<void> _sendOtp({bool resend = false}) async {
    final email = _emailCtrl.text.trim();
    if (!resend) {
      if (email.isEmpty) { setState(() => _emailError = 'Please enter your email'); return; }
      setState(() { _emailLoading = true; _emailError = null; });
    } else {
      setState(() { _otpResending = true; _otpError = null; });
      for (final c in _otpCtrls) {
        c.clear();
      }
      _otpNodes[0].requestFocus();
    }

    try {
      final fn = FirebaseFunctions.instance.httpsCallable('sendResetOtp');
      await fn.call({ 'email': email });

      if (!mounted) return;
      if (!resend) {
        setState(() { _emailLoading = false; _step = _Step.otp; });
      } else {
        setState(() => _otpResending = false);
      }
      _startTimer();
    } on FirebaseFunctionsException catch (e) {
      if (!mounted) return;
      setState(() {
        _emailLoading = false; _otpResending = false;
        if (!resend) {
          _emailError = e.message ?? 'Failed to send code.';
        } else {
          _otpError = e.message ?? 'Failed to resend. Try again.';
        }
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _emailLoading = false; _otpResending = false;
        if (!resend) {
          _emailError = 'Network error. Check your connection.';
        } else {
          _otpError = 'Network error. Check your connection.';
        }
      });
    }
  }

  void _startTimer() {
    setState(() { _seconds = 60; _canResend = false; });
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_seconds == 0) { t.cancel(); if (mounted) setState(() => _canResend = true); }
      else { if (mounted) setState(() => _seconds--); }
    });
  }

  // ── Verify OTP ────────────────────────────────────────────────────────────
  String get _otp => _otpCtrls.map((c) => c.text).join();

  void _onOtpChanged(int i, String val) {
    if (val.isNotEmpty && i < 5) _otpNodes[i + 1].requestFocus();
    setState(() => _otpError = null);
  }

  Future<void> _verifyOtp() async {
    if (_otp.length < 6) return;
    setState(() { _otpLoading = true; _otpError = null; });

    // We verify on the server when resetting — just move to next step
    await Future.delayed(const Duration(milliseconds: 300));
    _verifiedOtp = _otp;
    if (mounted) setState(() { _otpLoading = false; _step = _Step.password; });
  }

  // ── Reset password via Cloud Function ─────────────────────────────────────
  Future<void> _resetPassword() async {
    final pass    = _passCtrl.text;
    final confirm = _confirmCtrl.text;
    String? pe, ce;

    if (pass.isEmpty)    pe = 'Password is required';
    if (confirm.isEmpty) ce = 'Please confirm your password';
    if (pass.isNotEmpty && pass.length < 8) pe = 'At least 8 characters';
    if (pass.isNotEmpty && confirm.isNotEmpty && pass != confirm) ce = 'Passwords do not match';

    setState(() { _passError = pe; _confirmError = ce; });
    if (pe != null || ce != null) return;

    setState(() { _passLoading = true; _passError = null; });

    try {
      final fn = FirebaseFunctions.instance.httpsCallable('resetPasswordWithOtp');
      await fn.call({
        'email':       _emailCtrl.text.trim(),
        'otp':         _verifiedOtp,
        'newPassword': pass,
      });

      if (mounted) setState(() { _passLoading = false; _step = _Step.done; });
    } on FirebaseFunctionsException catch (e) {
      if (!mounted) return;
      final msg = e.message ?? 'Failed to reset password.';
      setState(() {
        _passLoading = false;
        // If OTP wrong/expired, go back to OTP step
        if (e.code == 'invalid-argument' && msg.contains('code') ||
            e.code == 'deadline-exceeded' || e.code == 'not-found') {
          _otpError = msg;
          _step = _Step.otp;
          for (final c in _otpCtrls) {
            c.clear();
          }
        } else {
          _passError = msg;
        }
      });
    } catch (_) {
      if (!mounted) return;
      setState(() { _passLoading = false; _passError = 'Network error. Try again.'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, size: 18),
          onPressed: () {
            if (_step == _Step.password) {
              setState(() => _step = _Step.otp);
            } else if (_step == _Step.otp) setState(() { _step = _Step.email; _timer?.cancel(); });
            else Navigator.pop(context);
          },
        ),
        title: Text(switch (_step) {
          _Step.email    => 'Forgot Password',
          _Step.otp      => 'Enter Code',
          _Step.password => 'New Password',
          _Step.done     => 'Done',
        }),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: switch (_step) {
            _Step.email    => _EmailStep(),
            _Step.otp      => _OtpStep(),
            _Step.password => _PasswordStep(),
            _Step.done     => _DoneStep(),
          },
        ),
      ),
    );
  }

  // ── UI: Email step ────────────────────────────────────────────────────────
  Widget _EmailStep() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const SizedBox(height: 16),
      _icon(Icons.lock_reset),
      const SizedBox(height: 20),
      _title('Forgot Password'),
      const SizedBox(height: 8),
      _subtitle('Enter your registered email and we will\nsend you a 6-digit verification code.'),
      const SizedBox(height: 32),
      _label('Email address'),
      const SizedBox(height: 6),
      TextField(
        controller: _emailCtrl,
        keyboardType: TextInputType.emailAddress,
        style: const TextStyle(color: AppColors.textPrimary),
        onChanged: (_) => setState(() => _emailError = null),
        decoration: InputDecoration(
          hintText: 'you@example.com',
          errorText: _emailError,
          errorStyle: const TextStyle(color: AppColors.red, fontSize: 11),
        ),
      ),
      const SizedBox(height: 24),
      _emailLoading
          ? _loader()
          : ElevatedButton(onPressed: _sendOtp, child: const Text('Send Code')),
    ],
  );

  // ── UI: OTP step ──────────────────────────────────────────────────────────
  Widget _OtpStep() => SingleChildScrollView(
    child: Column(children: [
      const SizedBox(height: 16),
      _icon(Icons.mail_outline),
      const SizedBox(height: 16),
      _title('Check your email'),
      const SizedBox(height: 8),
      _subtitle('We sent a 6-digit code to\n${_emailCtrl.text.trim()}'),
      const SizedBox(height: 28),

      if (_otpResending)
        _loader()
      else ...[
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(6, (i) => Container(
            width: 44, height: 52,
            margin: const EdgeInsets.symmetric(horizontal: 4),
            child: TextFormField(
              controller: _otpCtrls[i], focusNode: _otpNodes[i],
              textAlign: TextAlign.center,
              keyboardType: TextInputType.number, maxLength: 1,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary),
              decoration: InputDecoration(
                counterText: '', filled: true, fillColor: AppColors.bg3,
                contentPadding: EdgeInsets.zero,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(
                    color: _otpCtrls[i].text.isNotEmpty ? AppColors.accent : AppColors.border,
                    width: 2,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: AppColors.accent, width: 2),
                ),
              ),
              onChanged: (v) => _onOtpChanged(i, v),
              onTap: () => _otpCtrls[i].selection = TextSelection.fromPosition(
                  TextPosition(offset: _otpCtrls[i].text.length)),
            ),
          )),
        ),

        if (_otpError != null) ...[
          const SizedBox(height: 10),
          Text(_otpError!, style: const TextStyle(color: AppColors.red, fontSize: 12),
              textAlign: TextAlign.center),
        ],

        const SizedBox(height: 20),
        _otpLoading
            ? _loader()
            : ElevatedButton(
                onPressed: _otp.length == 6 ? _verifyOtp : null,
                child: const Text('Verify Code'),
              ),
        const SizedBox(height: 16),
        if (!_canResend)
          Text('Resend code in ${_seconds}s',
              style: const TextStyle(fontSize: 12, color: AppColors.textSecondary))
        else
          GestureDetector(
            onTap: () => _sendOtp(resend: true),
            child: const Text('Resend code',
                style: TextStyle(fontSize: 12, color: AppColors.accent,
                    fontWeight: FontWeight.w600)),
          ),
      ],
    ]),
  );

  // ── UI: Password step ─────────────────────────────────────────────────────
  Widget _PasswordStep() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const SizedBox(height: 16),
      _icon(Icons.lock_outline),
      const SizedBox(height: 20),
      _title('Set New Password'),
      const SizedBox(height: 8),
      _subtitle('Your identity is verified.\nChoose a strong new password.'),
      const SizedBox(height: 28),
      _label('New password'),
      const SizedBox(height: 6),
      TextField(
        controller: _passCtrl, obscureText: _obscurePass,
        style: const TextStyle(color: AppColors.textPrimary),
        onChanged: (_) => setState(() { _passError = null; _confirmError = null; }),
        decoration: InputDecoration(
          hintText: 'Min. 8 characters', errorText: _passError,
          errorStyle: const TextStyle(color: AppColors.red, fontSize: 11),
          suffixIcon: IconButton(
            icon: Icon(_obscurePass ? Icons.visibility_off : Icons.visibility,
                color: AppColors.textTertiary, size: 18),
            onPressed: () => setState(() => _obscurePass = !_obscurePass),
          ),
        ),
      ),
      const SizedBox(height: 16),
      _label('Confirm password'),
      const SizedBox(height: 6),
      TextField(
        controller: _confirmCtrl, obscureText: _obscureConfirm,
        style: const TextStyle(color: AppColors.textPrimary),
        onChanged: (_) => setState(() => _confirmError = null),
        decoration: InputDecoration(
          hintText: 'Repeat password', errorText: _confirmError,
          errorStyle: const TextStyle(color: AppColors.red, fontSize: 11),
          suffixIcon: IconButton(
            icon: Icon(_obscureConfirm ? Icons.visibility_off : Icons.visibility,
                color: AppColors.textTertiary, size: 18),
            onPressed: () => setState(() => _obscureConfirm = !_obscureConfirm),
          ),
        ),
      ),
      const SizedBox(height: 24),
      _passLoading
          ? _loader()
          : ElevatedButton(onPressed: _resetPassword, child: const Text('Reset Password')),
    ],
  );

  // ── UI: Done step ─────────────────────────────────────────────────────────
  Widget _DoneStep() => Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Container(
        width: 80, height: 80,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: AppColors.green, width: 3),
        ),
        child: const Icon(Icons.check, color: AppColors.green, size: 40),
      ),
      const SizedBox(height: 20),
      _title('Password Reset!'),
      const SizedBox(height: 10),
      _subtitle('Your password has been updated.\nSign in with your new password.'),
      const SizedBox(height: 32),
      ElevatedButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('Back to Sign In'),
      ),
    ],
  );

  Widget _icon(IconData icon) => Center(child: Container(
    width: 72, height: 72,
    decoration: BoxDecoration(shape: BoxShape.circle,
        border: Border.all(color: AppColors.accent, width: 2)),
    child: Icon(icon, color: AppColors.accent, size: 32),
  ));

  Widget _title(String t) => Center(child: Text(t,
      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700,
          color: AppColors.textPrimary)));

  Widget _subtitle(String t) => Center(child: Text(t,
      textAlign: TextAlign.center,
      style: const TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.6)));

  Widget _label(String t) => Text(t,
      style: const TextStyle(color: AppColors.textSecondary, fontSize: 12));

  Widget _loader() => const Center(child: CircularProgressIndicator(color: AppColors.accent));
}
