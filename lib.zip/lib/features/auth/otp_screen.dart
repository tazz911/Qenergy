// lib/features/auth/otp_screen.dart
import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import '../../core/theme/app_theme.dart';
import '../home/main_shell.dart';
 
class OtpScreen extends StatefulWidget {
  final String email;
  const OtpScreen({super.key, required this.email});
  @override State<OtpScreen> createState() => _OtpScreenState();
}
 
class _OtpScreenState extends State<OtpScreen> {
  final List<TextEditingController> _ctrls = List.generate(6, (_) => TextEditingController());
  final List<FocusNode> _nodes = List.generate(6, (_) => FocusNode());
  Timer? _timer;
  int _seconds = 60;
  bool _canResend = false;
  String? _error;
  bool _loading = false;
  bool _sending = true; // sending OTP on init
 
  // ── EmailJS credentials ──────────────────────────────
  static const _serviceId  = 'service_yy0rmcf';
  static const _templateId = 'template_5xusf8l';
  static const _publicKey  = 'w56Vc3uzNIEoiwtmn';
 
  // Generated OTP stored in memory
  String _generatedOtp = '';
 
  @override
  void initState() {
    super.initState();
    _sendOtp();
  }
 
  @override
  void dispose() {
    _timer?.cancel();
    for (final c in _ctrls) {
      c.dispose();
    }
    for (final n in _nodes) {
      n.dispose();
    }
    super.dispose();
  }
 
  // ── Generate random 6-digit OTP ───────────────────────
  String _generateOtp() {
    final rand = Random();
    return List.generate(6, (_) => rand.nextInt(10)).join();
  }
 
  // ── Send OTP via EmailJS ──────────────────────────────
  Future<void> _sendOtp() async {
    setState(() { _sending = true; _error = null; });
 
    _generatedOtp = _generateOtp();
 
    try {
      final response = await http.post(
        Uri.parse('https://api.emailjs.com/api/v1.0/email/send'),
        headers: {
          'Content-Type': 'application/json',
          'origin': 'https://localhost',
        },
        body: jsonEncode({
          'service_id':  _serviceId,
          'template_id': _templateId,
          'user_id':     _publicKey,
          'template_params': {
            'to_email': widget.email,
            'otp_code': _generatedOtp,
          },
        }),
      );
 
      if (response.statusCode == 200) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Verification code sent to your email!'),
            backgroundColor: AppColors.green,
          ));
        }
      } else {
        if (mounted) {
          setState(() => _error = 'Failed to send code. Please try again.');
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() => _error = 'Network error. Please check your connection.');
      }
    }
 
    if (mounted) {
      setState(() => _sending = false);
      _startTimer();
    }
  }
 
  void _startTimer() {
    setState(() { _seconds = 60; _canResend = false; });
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_seconds == 0) {
        t.cancel();
        if (mounted) setState(() => _canResend = true);
      } else {
        if (mounted) setState(() => _seconds--);
      }
    });
  }
 
  String get _otp => _ctrls.map((c) => c.text).join();
 
  void _onChanged(int i, String val) {
    if (val.isNotEmpty && i < 5) _nodes[i + 1].requestFocus();
    setState(() => _error = null);
  }
 
  Future<void> _verify() async {
    if (_otp.length < 6) return;
    setState(() { _loading = true; _error = null; });
    await Future.delayed(const Duration(milliseconds: 500));
 
    if (_otp == _generatedOtp) {
      if (mounted) {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (_) => const OtpSuccessScreen()),
          (_) => false,
        );
      }
    } else {
      setState(() {
        _error = 'Incorrect code. Please try again.';
        _loading = false;
        for (final c in _ctrls) {
          c.clear();
        }
      });
      _nodes[0].requestFocus();
    }
  }
 
  Future<void> _resend() async {
    for (final c in _ctrls) {
      c.clear();
    }
    setState(() => _error = null);
    _nodes[0].requestFocus();
    await _sendOtp();
  }
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Verify Email'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const SizedBox(height: 16),
              Container(
                width: 72, height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.accent, width: 2),
                ),
                child: const Icon(Icons.mail_outline, color: AppColors.accent, size: 32),
              ),
              const SizedBox(height: 16),
              const Text('Check your email',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
              const SizedBox(height: 8),
              Text(
                'We sent a 6-digit code to\n${widget.email}',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.6),
              ),
              const SizedBox(height: 28),
 
              // Show loading while sending
              if (_sending)
                const Column(children: [
                  CircularProgressIndicator(color: AppColors.accent),
                  SizedBox(height: 8),
                  Text('Sending code to your email...', style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                ])
              else ...[
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(6, (i) => Container(
                    width: 44, height: 52,
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    child: TextFormField(
                      controller: _ctrls[i],
                      focusNode: _nodes[i],
                      textAlign: TextAlign.center,
                      keyboardType: TextInputType.number,
                      maxLength: 1,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                      decoration: InputDecoration(
                        counterText: '',
                        filled: true,
                        fillColor: AppColors.bg3,
                        contentPadding: EdgeInsets.zero,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: AppColors.border, width: 2),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(
                            color: _ctrls[i].text.isNotEmpty ? AppColors.accent : AppColors.border,
                            width: 2,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: AppColors.accent, width: 2),
                        ),
                      ),
                      onChanged: (val) => _onChanged(i, val),
                      onTap: () => _ctrls[i].selection = TextSelection.fromPosition(
                          TextPosition(offset: _ctrls[i].text.length)),
                    ),
                  )),
                ),
                if (_error != null) ...[
                  const SizedBox(height: 10),
                  Text(_error!, style: const TextStyle(color: AppColors.red, fontSize: 12)),
                ],
                const SizedBox(height: 20),
                _loading
                    ? const CircularProgressIndicator(color: AppColors.accent)
                    : ElevatedButton(
                        onPressed: _otp.length == 6 ? _verify : null,
                        child: const Text('Verify Code'),
                      ),
                const SizedBox(height: 16),
                if (!_canResend)
                  Text('Resend code in ${_seconds}s',
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary))
                else
                  GestureDetector(
                    onTap: _resend,
                    child: const Text('Resend verification code',
                        style: TextStyle(fontSize: 12, color: AppColors.accent, fontWeight: FontWeight.w600)),
                  ),
              ],
 
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.accent.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.accent.withOpacity(0.2)),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.info_outline, color: AppColors.accent, size: 14),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Code expires in 10 minutes. Check your spam folder if not received.',
                        style: TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.5),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
 
class OtpSuccessScreen extends StatelessWidget {
  const OtpSuccessScreen({super.key});
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 80, height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.green, width: 3),
                ),
                child: const Icon(Icons.check, color: AppColors.green, size: 40),
              ),
              const SizedBox(height: 20),
              const Text('Email Verified!',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
              const SizedBox(height: 10),
              const Text(
                'Your account is created and your email is verified. You can now sign in securely.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.6),
              ),
              const SizedBox(height: 28),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.green.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.green.withOpacity(0.25)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(children: [
                      Icon(Icons.shield, color: AppColors.green, size: 16),
                      SizedBox(width: 6),
                      Text('Security summary',
                          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.green)),
                    ]),
                    const SizedBox(height: 10),
                    ...[ 
                      'Password hashed with bcrypt (salt rounds: 12)',
                      'OTP verified — email confirmed',
                      'Firebase Auth token issued',
                      'All data transmitted over HTTPS',
                    ].map((s) => Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Row(children: [
                        const Icon(Icons.check, color: AppColors.green, size: 12),
                        const SizedBox(width: 6),
                        Text(s, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                      ]),
                    )),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () => Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (_) => const MainShell()),
                  (_) => false,
                ),
                child: const Text('Go to Dashboard'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}